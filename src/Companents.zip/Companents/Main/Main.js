import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Home from '../Home/Home'
import Shop from './../Shop/Shop';
import Header from './../Header/Header';

const Main = () => {
    return (
        <div>

        <Header />

            <Switch>
                <Route exact path='/shop/all' component={Shop} />
                <Route exact path='/' component={Home} />
            </Switch>

        </div>
    );
};

export default Main;