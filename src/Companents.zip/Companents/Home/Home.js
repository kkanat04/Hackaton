import React from 'react';
import './Home.css'
import Home1 from './Home1/Home1';

function Home(props) {
    return (
        <div className='page'>
        <div class="ImageHero">

        <div className='page1'>
            <div className='signature'>
           <h2 className='line'>SIGNATURE LINE</h2>

           <p className='discover'>Discover new styles added to our signature line</p>
           </div>
        </div>
         
          
           </div>

           <Home1 />
        </div>
    );
}

export default Home; 