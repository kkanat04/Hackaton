export const API = 'http://192.168.0.109:8000/api/v1/list_product/'

export const AUTH = 'http://192.168.0.109:8000/api/v1/auth/users/'

export const LOGIN = 'http://192.168.0.109:8000/api/v1/auth_token/token/login'